To run post processing script, install following dependencies:
openCV
numpy

Replace line 10 with you own map (or leaves ours as a demo)

See 'Media' folder for full library of generated maps